/* 
 * File:   Pedido.h
 * Author: Ivan
 *
 * Created on 12 de octubre de 2024, 8:07
 */

#ifndef PEDIDO_H
#define PEDIDO_H

struct Pedido{
    char *id;
    int tiempoPreparacion;
    int tiempoEstimadoViaje;
};

#endif /* PEDIDO_H */

