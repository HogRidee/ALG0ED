/* 
 * File:   Efectivo.h
 * Author: Ivan
 *
 * Created on 12 de octubre de 2024, 9:26
 */

#ifndef EFECTIVO_H
#define EFECTIVO_H

struct Efectivo{
    int id;
    int grado;
    int tiempo;
};

#endif /* EFECTIVO_H */

